return {
	"_preload.lua",
	"netbeans.lua",
	"netbeans_makefile.lua",
	"netbeans_project.lua",
	"netbeans_configurations.lua",
}
