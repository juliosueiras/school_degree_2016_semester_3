# NetBeans Premake5 action

Supported features:

* C/C++ projects

Todo:

* Java?